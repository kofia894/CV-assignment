
function storeValues() {
    let fnamex = document.getElementById('fname').value;
    let mnamex = document.getElementById('mname').value;
    let lnamex = document.getElementById('lname').value;
    let pnumberx = document.getElementById('pnumber').value;
    let emailx = document.getElementById('email').value;
    let addressx = document.getElementById('address').value;
    let genderx = document.getElementById('gender').value;
    let namex = fnamex + " " + mnamex + " " + lnamex;

    localStorage.setItem('nm', namex);
    localStorage.setItem('gn', genderx);
    localStorage.setItem('pn', pnumberx);
    localStorage.setItem('em', emailx);
    localStorage.setItem('ad',addressx);
     
}

document.getElementById('name1').innerHTML= localStorage.getItem('nm');
document.getElementById('address1').innerHTML= localStorage.getItem('ad');
document.getElementById('phone1').innerHTML= localStorage.getItem('pn');
document.getElementById('email1').innerHTML= localStorage.getItem('em');
document.getElementById('gender1').innerHTML= localStorage.getItem('gn');




